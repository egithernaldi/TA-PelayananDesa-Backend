
  
<?php $__env->startSection('contents'); ?>
    <div class="d-flex align-items-center justify-content-between">
        <h1 class="mb-0">Surat Keterangan Domisili</h1>
        <a href="<?php echo e(route('domisili.create')); ?>" class="btn btn-primary">Buat Surat</a>
    </div>
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>
    <table class="table table-hover mt-3">
        <thead class="table-primary">
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>NIK</th>
                <th>Jenis Kelamin</th>
                <th>Kewarganegaraan</th>
                <th>Status Pengajuan</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $counter = 1;
            ?>
            <?php $__empty_1 = true; $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $user = App\Models\User::find($rs->id_user)
            ?>
                
                <?php if($rs->id_surat == 1): ?> 
                    <tr>
                        <td><?php echo e($counter++); ?></td>
                        <td><?php echo e($user->nama); ?></td>
                        <td><?php echo e($user->nik); ?></td>
                        <td><?php echo e($user->jenis_kelamin); ?></td>
                        <td><?php echo e($user->alamat); ?></td>
                        <td><?php echo $rs->status; ?></td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <a href="<?php echo e(route('domisili.show', $rs->id)); ?>" class="btn btn-primary">Detail</a>
                                <a href="<?php echo e(route('domisili.edit', $rs->id)); ?>" class="btn btn-warning">Edit</a>
                                <form action="<?php echo e(route('domisili.destroy', $rs->id)); ?>" method="POST" onsubmit="return confirm('Delete?')" class="mr-1">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger">Delete</button>
                                </form>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Status
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <?php if($rs->status_pengajuan != 4): ?>
                                            <form action="<?php echo e(route('domisili.updateStatus', $rs->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <input type="hidden" name="status_pengajuan" value="2">
                                                <button class="dropdown-item" onclick="return confirm('Yakin ingin mengubah status pengajuan?')">Diterima</button>
                                            </form>
                                            <form action="<?php echo e(route('domisili.updateStatus', $rs->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <input type="hidden" name="status_pengajuan" value="4">
                                                <button class="dropdown-item" onclick="return confirm('Yakin ingin mengubah status pengajuan?')">Selesai</button>
                                            </form>
                                            <form action="<?php echo e(route('domisili.updateStatus', $rs->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <input type="hidden" name="status_pengajuan" value="3">
                                                <button class="dropdown-item" onclick="return confirm('Yakin ingin mengubah status pengajuan?')">Ditolak</button>
                                            </form>
                                            
    
                                        <?php else: ?>
                                            <button class="dropdown-item" disabled>Selesai</button>
                                            <a href="<?php echo e(route('admin.domisili.cetak', $rs->id)); ?>" target="_blank" class="btn btn-warning">Cetak</a>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td class="text-center" colspan="6">Surat Tidak Ada</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\suratdesa2\resources\views/admin/domisili/index.blade.php ENDPATH**/ ?>