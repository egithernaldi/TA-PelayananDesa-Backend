
  
<?php $__env->startSection('contents'); ?>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h1 class="mb-0">Detail Surat</h1>
            </div>
            <div class="card-body">
                <form>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label">Nama</label>
                        <div class="col-sm-4">
                            <input type="text" name="nama" class="form-control" placeholder="Nama" value="<?php echo e($detail->nama); ?>" readonly>
                        </div>
                        <label class="col-sm-2 col-form-label">NIK</label>
                        <div class="col-sm-4">
                            <input type="text" name="nik" class="form-control" placeholder="NIK" value="<?php echo e($detail->nik); ?>" readonly>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label">Nama Usaha</label>
                        <div class="col-sm-4">
                            <input type="text" name="nama_usaha" class="form-control" placeholder="Nama Usaha" value="<?php echo e($detail->nama_usaha); ?>" readonly>
                        </div>
                        <label class="col-sm-2 col-form-label">Tempat Usaha</label>
                        <div class="col-sm-4">
                            <input type="text" name="tempatusaha" class="form-control" placeholder="Tempat Usaha" value="<?php echo e($detail->tempat_usaha); ?>" readonly>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label">Alamat</label>
                        <div class="col-sm-4">
                            <input type="text" name="alamat" class="form-control" placeholder="Alamat" value="<?php echo e($detail->alamat); ?>" readonly>
                        </div>
                        <label class="col-sm-2 col-form-label">Telepon</label>
                        <div class="col-sm-4">
                            <input type="text" name="telepon" class="form-control" placeholder="telepon" value="<?php echo e($detail->telepon); ?>" readonly>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label">Tanggal Lahir</label>
                        <div class="col-sm-4">
                            <input type="date" name="tanggal_lahir" class="form-control" value="<?php echo e($detail->tanggal_lahir); ?>" readonly>
                        </div>
                        <label class="col-sm-2 col-form-label">Agama</label>
                        <div class="col-sm-4">
                            <input type="text" name="agama" class="form-control" placeholder="Agama" value="<?php echo e($detail->agama); ?>" readonly>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label">Tempat Lahir</label>
                        <div class="col-sm-4">
                            <input type="text" name="tempat_lahir" class="form-control" placeholder="Tempat Lahir" value="<?php echo e($detail->tempat_lahir); ?>" readonly>
                        </div>
                        <label class="col-sm-2 col-form-label">Jenis Kelamin</label>
                        <div class="col-sm-4">
                            <input type="text" name="jekel" class="form-control" placeholder="Jenis Kelamin" value="<?php echo e($detail->jenis_kelamin); ?>" readonly>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\suratdesa2\resources\views/admin/usaha/show.blade.php ENDPATH**/ ?>