<footer class="sticky-footer bg-white">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Your Website 2023</span>
      </div>
    </div>
  </footer><?php /**PATH D:\suratdesa\resources\views/layouts/footer.blade.php ENDPATH**/ ?>