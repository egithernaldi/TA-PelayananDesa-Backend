

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row min-h-screen align-items-center justify-content-between">
        <div class="col-7">
            <div class="container">
                <div class="d-flex flex-column justify-content-center align-items-center mb-5">
                        <img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="Logo" width="130" height="100">
                    </a>
                    <h1>Login</h1>
                </div>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('login.action')); ?>" method="POST" class="user">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="email" class="mb-4">Email</label>
                        <input name="email" type="email" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter Email Address...">
                    </div>

                    <div class="form-group position-relative">
                        <label for="password" class="mb-4">Password</label>
                        <div class="input-group" id="show_hide_password">
                          <input name="password" type="password" class="form-control form-control-user" id="exampleInputPassword" placeholder="Password">
                            <div class="position-absolute right-midlle">
                                <a href=""><i class="fa fa-eye-slash" aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <?php if($errors->has('password')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('password')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="d-flex w-100 justify-content-center mt-5">
                        <button type="submit" class="btn btn-primary btn-green-pastel px-5 py-2 rounded-pill">Login</button>
                    </div>
                </form>

                <div class="d-flex justify-content-center mt-3">
                    <p class="text-center">Belum punya akun? <a href="<?php echo e(route('register')); ?>">Register</a></p>
                </div>
            </div>
        </div>
        <div class="col-4">
            <img src="<?php echo e(asset('img/banner-login.webp')); ?>" alt="logo" class="img-fluid">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .right-midlle {
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            z-index: 9999;
        }

        .btn-green-pastel {
            background-color: #51839C;
            border-color: #51839C;
            color: #fff;
        }

        .btn-green-pastel:hover {
            background-color: #3B6C81;
            border-color: #3B6C81;
            color: #fff;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $("#show_hide_password a").on('click', function(event) {
                event.preventDefault();
                if ($('#show_hide_password input').attr("type") == "text") {
                    $('#show_hide_password input').attr('type', 'password');
                    $('#show_hide_password i').addClass("fa-eye-slash");
                    $('#show_hide_password i').removeClass("fa-eye");
                } else if ($('#show_hide_password input').attr("type") == "password") {
                    $('#show_hide_password input').attr('type', 'text');
                    $('#show_hide_password i').removeClass("fa-eye-slash");
                    $('#show_hide_password i').addClass("fa-eye");
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\suratdesa\resources\views/auth/login.blade.php ENDPATH**/ ?>