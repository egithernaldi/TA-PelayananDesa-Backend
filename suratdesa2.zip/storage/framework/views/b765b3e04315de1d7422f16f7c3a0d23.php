<nav class="navbar navbar-expand-lg navbar-light bg-light py-4" style="z-index: 2;">
  <div class="container">
      <a class="navbar-brand d-flex align-items-center" href="">
          <img src="<?php echo e(asset('img/logo.jpg')); ?>" class="d-inline-block" width="50" height="50" alt="">
          <div class="d-flex flex-column ml-3">
              <span class="text-sm">Desa</span>
              <span class="text-bold text-sm">Alon-Alon</span>
          </div>
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent" style="color: #000000;">
          <ul class="navbar-nav ml-auto">
              <li class="nav-item mr-4">
                  <a class="nav-link font-weight-bold" href="#profile">Profile Desa</a>
              </li>
              <li class="nav-item dropdown mr-4">
                  <a class="nav-link font-weight-bold dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                      Layanan
                  </a>
                  <div class="dropdown-menu">
                      <a class="dropdown-item" href="">Pengajuan Surat Pengantar</a>
                      <a class="dropdown-item" href="">Aduan Masyarakat</a>
                  </div>
              </li>
              <li class="nav-item mr-4">
                  <a class="nav-link font-weight-bold" href="">Informasi</a>
              </li>
              <li class="nav-item mr-4">
                  <a class="nav-link font-weight-bold" href="#kontak">Kontak</a>
              </li>
              <?php if(Auth::check()): ?>
                  <li class="nav-item dropdown mr-4">
                  </li>
              <?php else: ?>
                  <li class="nav-item">
                      <a class="nav-link font-weight-bold btn rounded-pill" href="<?php echo e(route('login')); ?>" style="background-color: #51839C; color: #FFFFFF; padding: 8px 42px;">Login</a>
                  </li>
              <?php endif; ?>
          </ul>
      </div>
</nav>
<?php /**PATH D:\suratdesa\resources\views/layouts/navbar1.blade.php ENDPATH**/ ?>